using System.Numerics;
using System.Text;

namespace VighneshPayroll.Services;

public sealed class ColInfo
{
    public int ColId; public string Name = ""; public byte XType; public short Length; public byte Prec; public byte Scale;
}

internal sealed class Rec
{
    public byte[] Fixed = Array.Empty<byte>();
    public byte[] Bitmap = Array.Empty<byte>();
    public List<byte[]> Var = new();
    public int NCols;
}

/// <summary>
/// Reads the raw data pages of an uncompressed, unencrypted native SQL Server full backup (.bak)
/// without needing SQL Server. Port of the tested Python converter.
/// </summary>
public sealed class BakReader
{
    const int Page = 8192;
    static readonly HashSet<byte> VarTypes = new() { 231, 167, 165, 173, 99, 35, 34, 241, 239 };

    readonly Dictionary<(uint, ushort), List<byte[]>> byObj = new();
    readonly Dictionary<int, string> tables = new();
    readonly Dictionary<int, List<ColInfo>> cols = new();
    readonly Dictionary<int, HashSet<uint>> dataObjs = new();
    readonly Action<string> log;
    public int PageCount { get; private set; }
    public int TableCount => tables.Count;

    public BakReader(byte[] d, Action<string> log)
    {
        this.log = log;
        var cands = new List<int>();
        for (int o = 0; o + Page <= d.Length; o++)
            if (d[o] == 1 && Valid(d, o)) cands.Add(o);
        if (cands.Count == 0)
            throw new InvalidDataException("No SQL Server data pages found. The backup is probably COMPRESSED or ENCRYPTED, or is not a SQL Server backup. " +
                                           "Make a new backup without compression (WITH NO_COMPRESSION) and try again.");
        var align = new Dictionary<int, int>();
        foreach (var o in cands) align[o % Page] = align.GetValueOrDefault(o % Page) + 1;
        var keep = new HashSet<int>(align.Where(k => k.Value >= 8).Select(k => k.Key));
        if (keep.Count == 0) keep.Add(align.OrderByDescending(k => k.Value).First().Key);

        var pages = new Dictionary<(ushort, uint), byte[]>();
        foreach (var o in cands)
        {
            if (!keep.Contains(o % Page)) continue;
            var p = new byte[Page];
            Buffer.BlockCopy(d, o, p, 0, Page);
            pages[(BitConverter.ToUInt16(p, 36), BitConverter.ToUInt32(p, 32))] = p;   // later copy wins
        }
        PageCount = pages.Count;
        foreach (var p in pages.Values)
        {
            if (p[1] != 1) continue;
            var key = (BitConverter.ToUInt32(p, 24), BitConverter.ToUInt16(p, 6));
            if (!byObj.TryGetValue(key, out var l)) byObj[key] = l = new List<byte[]>();
            l.Add(p);
        }
        log($"Found {PageCount} database pages.");
        BuildCatalog();
        log($"Catalog: {tables.Count} user tables.");
    }

    static bool Valid(byte[] d, int o)
    {
        byte t = d[o + 1];
        if (!(t is 1 or 2 or 3 or 4 or 8 or 9 or 10 or 11 or 13 or 15 or 16 or 17)) return false;
        ushort fid = BitConverter.ToUInt16(d, o + 36);
        if (fid < 1 || fid > 4) return false;
        if (BitConverter.ToUInt32(d, o + 32) > 5_000_000) return false;
        if (BitConverter.ToUInt16(d, o + 22) > 4000) return false;
        if (BitConverter.ToUInt16(d, o + 30) > Page) return false;
        return true;
    }

    static IEnumerable<int> Slots(byte[] p)
    {
        int n = BitConverter.ToUInt16(p, 22);
        for (int i = 0; i < n; i++)
        {
            int off = BitConverter.ToUInt16(p, Page - 2 * (i + 1));
            if (off >= 96 && off < Page) yield return off;
        }
    }

    static byte[] Slice(byte[] p, int a, int b)
    {
        if (b < a) b = a;
        a = Math.Clamp(a, 0, p.Length); b = Math.Clamp(b, 0, p.Length);
        var r = new byte[b - a];
        Buffer.BlockCopy(p, a, r, 0, b - a);
        return r;
    }

    static Rec? Parse(byte[] p, int off)
    {
        try
        {
            byte s0 = p[off];
            int rt = (s0 >> 1) & 7;
            if (rt != 0 && rt != 1) return null;
            int fend = BitConverter.ToUInt16(p, off + 2);
            int ncols = BitConverter.ToUInt16(p, off + fend);
            int nb = (ncols + 7) / 8;
            var rec = new Rec { NCols = ncols };
            rec.Fixed = Slice(p, off + 4, off + fend);
            rec.Bitmap = Slice(p, off + fend + 2, off + fend + 2 + nb);
            int pos = off + fend + 2 + nb;
            if ((s0 & 0x20) != 0)
            {
                int nvar = BitConverter.ToUInt16(p, pos);
                var offs = new int[nvar];
                for (int k = 0; k < nvar; k++) offs[k] = BitConverter.ToUInt16(p, pos + 2 + 2 * k) & 0x7fff;
                int prev = pos + 2 + 2 * nvar;
                foreach (var e in offs)
                {
                    int end = off + e;
                    if (end >= prev && end <= Page) { rec.Var.Add(Slice(p, prev, end)); prev = end; }
                    else rec.Var.Add(Array.Empty<byte>());
                }
            }
            return rec;
        }
        catch { return null; }
    }

    static bool IsNull(Rec r, int idx) =>
        idx < r.NCols && idx / 8 < r.Bitmap.Length && ((r.Bitmap[idx / 8] >> (idx % 8)) & 1) != 0;

    IEnumerable<Rec> SysRows(int obj)
    {
        foreach (var kv in byObj)
        {
            if (kv.Key.Item1 != (uint)obj || kv.Key.Item2 > 1) continue;
            foreach (var p in kv.Value)
                foreach (var off in Slots(p))
                {
                    var r = Parse(p, off);
                    if (r != null) yield return r;
                }
        }
    }

    void BuildCatalog()
    {
        foreach (var r in SysRows(34))                       // sysschobjs
        {
            var f = r.Fixed;
            if (f.Length < 15 || r.Var.Count == 0) continue;
            int oid = BitConverter.ToInt32(f, 0);
            if (f[13] == (byte)'U' && f[14] == (byte)' ') tables[oid] = Encoding.Unicode.GetString(r.Var[0]);
        }
        foreach (var r in SysRows(41))                       // syscolpars
        {
            var f = r.Fixed;
            if (f.Length < 19 || r.Var.Count == 0) continue;
            int oid = BitConverter.ToInt32(f, 0);
            if (!tables.ContainsKey(oid)) continue;
            if (!cols.TryGetValue(oid, out var l)) cols[oid] = l = new List<ColInfo>();
            l.Add(new ColInfo
            {
                ColId = BitConverter.ToInt32(f, 6), Name = Encoding.Unicode.GetString(r.Var[0]), XType = f[10],
                Length = BitConverter.ToInt16(f, 15), Prec = f[17], Scale = f[18]
            });
        }
        foreach (var l in cols.Values) l.Sort((a, b) => a.ColId.CompareTo(b.ColId));

        var rowsets = new Dictionary<long, (int major, int minor)>();
        foreach (var r in SysRows(5))                        // sysrowsets
        {
            var f = r.Fixed;
            if (f.Length >= 17) rowsets[BitConverter.ToInt64(f, 0)] = (BitConverter.ToInt32(f, 9), BitConverter.ToInt32(f, 13));
        }
        foreach (var r in SysRows(7))                        // sysallocunits
        {
            var f = r.Fixed;
            if (f.Length < 17) continue;
            long auid = BitConverter.ToInt64(f, 0); byte typ = f[8]; long owner = BitConverter.ToInt64(f, 9);
            if (typ == 1 && rowsets.TryGetValue(owner, out var rs) && tables.ContainsKey(rs.major) && rs.minor is 0 or 1)
            {
                if (!dataObjs.TryGetValue(rs.major, out var set)) dataObjs[rs.major] = set = new HashSet<uint>();
                set.Add((uint)(((ulong)auid >> 16) & 0xFFFFFFFFUL));
            }
        }
    }

    public List<Dictionary<string, object?>> Table(string name)
    {
        var result = new List<Dictionary<string, object?>>();
        int oid = tables.FirstOrDefault(k => string.Equals(k.Value, name, StringComparison.OrdinalIgnoreCase)).Key;
        if (oid == 0 || !cols.TryGetValue(oid, out var cl) || !dataObjs.TryGetValue(oid, out var objs)) return result;
        var fixedCols = new List<(int i, ColInfo c)>();
        var varCols = new List<(int i, ColInfo c)>();
        for (int i = 0; i < cl.Count; i++) (VarTypes.Contains(cl[i].XType) ? varCols : fixedCols).Add((i, cl[i]));

        foreach (var kv in byObj)
        {
            if (!objs.Contains(kv.Key.Item1)) continue;
            foreach (var p in kv.Value)
                foreach (var off in Slots(p))
                {
                    var r = Parse(p, off);
                    if (r == null) continue;
                    try { result.Add(Decode(r, fixedCols, varCols)); } catch { }
                }
        }
        return result;
    }

    static Dictionary<string, object?> Decode(Rec r, List<(int i, ColInfo c)> fixedCols, List<(int i, ColInfo c)> varCols)
    {
        var f = r.Fixed; int pos = 0; int bitbyte = 0, bitn = 8;
        var vals = new Dictionary<string, object?>(StringComparer.OrdinalIgnoreCase);
        foreach (var (i, c) in fixedCols)
        {
            object? v = null;
            if (c.XType == 104)
            {
                if (bitn >= 8) { bitbyte = pos < f.Length ? f[pos] : 0; pos++; bitn = 0; }
                v = (bitbyte >> bitn) & 1; bitn++;
            }
            else
            {
                bitn = 8;
                if (c.XType == 106 || c.XType == 108)
                {
                    int sz = c.Prec <= 9 ? 5 : c.Prec <= 19 ? 9 : c.Prec <= 28 ? 13 : 17;
                    if (pos + sz <= f.Length)
                    {
                        var n = new BigInteger(f.AsSpan(pos + 1, sz - 1), isUnsigned: true);
                        double dv = (double)n / Math.Pow(10, c.Scale);
                        v = f[pos] == 1 ? dv : -dv;
                    }
                    pos += sz;
                }
                else
                {
                    int sz = c.XType switch
                    {
                        56 => 4, 127 => 8, 52 => 2, 48 => 1, 40 => 3, 61 => 8, 58 => 4, 60 => 8, 62 => 8, 59 => 4, 36 => 16, 122 => 4,
                        _ => c.Length > 0 ? c.Length : 0
                    };
                    if (pos + sz <= f.Length)
                    {
                        v = c.XType switch
                        {
                            56 => BitConverter.ToInt32(f, pos),
                            127 => BitConverter.ToInt64(f, pos),
                            52 => (int)BitConverter.ToInt16(f, pos),
                            48 => (int)f[pos],
                            40 => new DateTime(1, 1, 1).AddDays(f[pos] | (f[pos + 1] << 8) | (f[pos + 2] << 16)).ToString("yyyy-MM-dd"),
                            61 => new DateTime(1900, 1, 1).AddDays(BitConverter.ToInt32(f, pos + 4))
                                      .AddSeconds(BitConverter.ToUInt32(f, pos) / 300.0).ToString("yyyy-MM-dd HH:mm:ss"),
                            62 => BitConverter.ToDouble(f, pos),
                            _ => Convert.ToHexString(f, pos, sz)
                        };
                    }
                    pos += sz;
                }
            }
            vals[c.Name] = IsNull(r, i) ? null : v;
        }
        for (int k = 0; k < varCols.Count; k++)
        {
            var (i, c) = varCols[k];
            byte[] raw = k < r.Var.Count ? r.Var[k] : Array.Empty<byte>();
            object? v;
            if (IsNull(r, i)) v = null;
            else if (c.XType is 231 or 99) v = Encoding.Unicode.GetString(raw);
            else if (c.XType is 167 or 35) v = Encoding.Latin1.GetString(raw);
            else v = Convert.ToHexString(raw);
            vals[c.Name] = v;
        }
        return vals;
    }
}
