using System.Globalization;
using System.Text.RegularExpressions;
using Microsoft.Data.Sqlite;

namespace VighneshPayroll.Data;

/// <summary>Row wrapper with typed accessors (replaces DataTable/DataRow from the web app).</summary>
public sealed class Row
{
    private readonly Dictionary<string, object?> _d;
    public Row(Dictionary<string, object?> d) { _d = d; }
    public object? this[string k] => _d.TryGetValue(k, out var v) ? v : null;
    public string S(string k) => Convert.ToString(this[k], CultureInfo.InvariantCulture) ?? "";
    public decimal D(string k) => this[k] == null ? 0m : Convert.ToDecimal(this[k], CultureInfo.InvariantCulture);
    public int I(string k) => this[k] == null ? 0 : Convert.ToInt32(this[k], CultureInfo.InvariantCulture);
    public bool B(string k) => this[k] != null && Convert.ToInt32(this[k], CultureInfo.InvariantCulture) != 0;
    public DateTime? Dt(string k) => this[k] == null ? null : DateTime.Parse(S(k), CultureInfo.InvariantCulture);
}

/// <summary>
/// SQLite access. Keeps the web app's "?" positional-parameter style so SQL ported from
/// the ASP.NET pages needs minimal change. The database file lives in the app's private
/// storage on the phone.
/// </summary>
public static class Db
{
    public static string FilePath => Path.Combine(FileSystem.AppDataDirectory, "empsalary.db3");
    public const string DateFmt = "yyyy-MM-dd";

    private static bool _init;
    public static void Init()
    {
        if (_init) return;
        SQLitePCL.Batteries_V2.Init();
        _init = true;
    }

    public static SqliteConnection Open()
    {
        Init();
        var c = new SqliteConnection($"Data Source={FilePath}");
        c.Open();
        using var p = c.CreateCommand();
        p.CommandText = "PRAGMA foreign_keys=ON;";
        p.ExecuteNonQuery();
        return c;
    }

    private static SqliteCommand Build(SqliteConnection con, string sql, object?[] args)
    {
        int i = 0;
        sql = Regex.Replace(sql, @"\?", _ => "@p" + (i++));
        if (i != args.Length) throw new InvalidOperationException("SQL parameter count does not match query.");
        var cmd = con.CreateCommand();
        cmd.CommandText = sql;
        for (int k = 0; k < args.Length; k++)
        {
            object? v = args[k];
            if (v is DateTime dt) v = dt.ToString(DateFmt, CultureInfo.InvariantCulture);
            else if (v is bool b) v = b ? 1 : 0;
            else if (v is decimal m) v = (double)m;
            cmd.Parameters.AddWithValue("@p" + k, v ?? DBNull.Value);
        }
        return cmd;
    }

    public static List<Row> Query(string sql, params object?[] args)
    {
        using var con = Open();
        using var cmd = Build(con, sql, args);
        using var r = cmd.ExecuteReader();
        var list = new List<Row>();
        while (r.Read())
        {
            var d = new Dictionary<string, object?>(StringComparer.OrdinalIgnoreCase);
            for (int i = 0; i < r.FieldCount; i++) d[r.GetName(i)] = r.IsDBNull(i) ? null : r.GetValue(i);
            list.Add(new Row(d));
        }
        return list;
    }

    public static int Execute(string sql, params object?[] args)
    {
        using var con = Open();
        using var cmd = Build(con, sql, args);
        return cmd.ExecuteNonQuery();
    }

    public static object? Scalar(string sql, params object?[] args)
    {
        using var con = Open();
        using var cmd = Build(con, sql, args);
        var v = cmd.ExecuteScalar();
        return v == DBNull.Value ? null : v;
    }

    public static long Insert(string sql, params object?[] args)
    {
        using var con = Open();
        using var cmd = Build(con, sql, args);
        cmd.ExecuteNonQuery();
        using var id = con.CreateCommand();
        id.CommandText = "SELECT last_insert_rowid()";
        return Convert.ToInt64(id.ExecuteScalar(), CultureInfo.InvariantCulture);
    }

    /// <summary>Run several statements atomically.</summary>
    public static void Transaction(Action<Func<string, object?[], int>> work)
    {
        using var con = Open();
        using var tx = con.BeginTransaction();
        try
        {
            work((sql, a) => { using var c = Build(con, sql, a); c.Transaction = tx; return c.ExecuteNonQuery(); });
            tx.Commit();
        }
        catch { tx.Rollback(); throw; }
    }
}
