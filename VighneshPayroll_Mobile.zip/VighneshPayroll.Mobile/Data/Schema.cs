namespace VighneshPayroll.Data;

/// <summary>SQLite equivalent of V1021SchemaService (SQL Server). One organisation per phone.</summary>
public static class Schema
{
    private static readonly string[] Ddl =
    {
        "CREATE TABLE IF NOT EXISTS Settings (Key TEXT PRIMARY KEY, Value TEXT)",
        @"CREATE TABLE IF NOT EXISTS Users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE COLLATE NOCASE,
            password_hash TEXT NOT NULL,
            IsAdmin INTEGER NOT NULL DEFAULT 0,
            IsActive INTEGER NOT NULL DEFAULT 1)",
        "CREATE TABLE IF NOT EXISTS Branches (BranchCode TEXT PRIMARY KEY, IsActive INTEGER NOT NULL DEFAULT 1)",
        @"CREATE TABLE IF NOT EXISTS Employees (
            EmployeeID INTEGER PRIMARY KEY AUTOINCREMENT,
            EmployeeCode TEXT NULL,
            EmployeeName TEXT NOT NULL,
            Designation TEXT NULL,
            BranchCode TEXT NOT NULL,
            DateOfJoining TEXT NULL,
            PFMember INTEGER NOT NULL DEFAULT 0,
            ESIMember INTEGER NOT NULL DEFAULT 0,
            UANNo TEXT NULL, ESINo TEXT NULL,
            BankAccount TEXT NULL, BankName TEXT NULL, IFSCCode TEXT NULL,
            StandardSalaryPrev REAL NOT NULL DEFAULT 0,
            IncrementAmount REAL NOT NULL DEFAULT 0,
            SalaryAdjustment REAL NOT NULL DEFAULT 0,
            IsActive INTEGER NOT NULL DEFAULT 1)",
        // The web app derives DeductionDays from daily punches; on the phone the
        // admin enters the month's summary directly.
        @"CREATE TABLE IF NOT EXISTS MonthlyAttendance (
            EmployeeID INTEGER NOT NULL,
            AttendanceMonth TEXT NOT NULL,
            Lates INTEGER NOT NULL DEFAULT 0,
            Permissions INTEGER NOT NULL DEFAULT 0,
            DeductionDays REAL NOT NULL DEFAULT 0,
            Remarks TEXT NULL,
            PRIMARY KEY (EmployeeID, AttendanceMonth))",
        @"CREATE TABLE IF NOT EXISTS Payroll (
            PayrollID INTEGER PRIMARY KEY AUTOINCREMENT,
            EmployeeID INTEGER NOT NULL,
            SalaryMonth TEXT NOT NULL,
            DaysInMonth INTEGER NOT NULL DEFAULT 30,
            Leaves REAL NOT NULL DEFAULT 0,
            StandardSalary REAL NOT NULL DEFAULT 0, LOP REAL NOT NULL DEFAULT 0,
            GrossSalary REAL NOT NULL DEFAULT 0, Basic REAL NOT NULL DEFAULT 0, DA REAL NOT NULL DEFAULT 0,
            PF REAL NOT NULL DEFAULT 0, ESI REAL NOT NULL DEFAULT 0, PT REAL NOT NULL DEFAULT 0,
            SalaryAdvance REAL NOT NULL DEFAULT 0, OtherDeductions REAL NOT NULL DEFAULT 0,
            TotalDeductions REAL NOT NULL DEFAULT 0, NetPay REAL NOT NULL DEFAULT 0,
            CreatedOn TEXT NOT NULL DEFAULT (datetime('now')),
            UNIQUE (EmployeeID, SalaryMonth))",
        @"CREATE TABLE IF NOT EXISTS Loans (
            LoanID INTEGER PRIMARY KEY AUTOINCREMENT,
            EmployeeID INTEGER NOT NULL,
            TxnDate TEXT NOT NULL,
            OpeningBalance REAL NOT NULL DEFAULT 0, LoanAvailed REAL NOT NULL DEFAULT 0,
            Deduction REAL NOT NULL DEFAULT 0, NetBalance REAL NOT NULL DEFAULT 0,
            Remarks TEXT NULL)",
        @"CREATE TABLE IF NOT EXISTS StatutoryRules (
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            RuleKey TEXT NOT NULL, RuleValue REAL NOT NULL, EffectiveFrom TEXT NOT NULL,
            Notes TEXT NULL, CreatedOn TEXT NOT NULL DEFAULT (datetime('now')))",
        @"CREATE TABLE IF NOT EXISTS SystemAudit (
            AuditID INTEGER PRIMARY KEY AUTOINCREMENT,
            UserName TEXT NULL, ActionName TEXT NOT NULL, Details TEXT NULL,
            CreatedOn TEXT NOT NULL DEFAULT (datetime('now')))",
        "CREATE INDEX IF NOT EXISTS IX_Loans_Emp ON Loans(EmployeeID, TxnDate)",
        "CREATE INDEX IF NOT EXISTS IX_Payroll_Month ON Payroll(SalaryMonth)"
    };

    public static void EnsureCreated()
    {
        foreach (var s in Ddl) Db.Execute(s);
        if (Convert.ToInt32(Db.Scalar("SELECT COUNT(*) FROM StatutoryRules")) == 0)
            foreach (var k in Core.StatutoryRules.AllKeys)
                Db.Execute("INSERT INTO StatutoryRules (RuleKey,RuleValue,EffectiveFrom,Notes) VALUES (?,?,'2000-01-01','Built-in default')",
                    k, Core.StatutoryRules.DefaultFor(k));
    }
}
