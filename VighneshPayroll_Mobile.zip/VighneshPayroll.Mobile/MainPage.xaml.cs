namespace VighneshPayroll;

public partial class MainPage : ContentPage
{
    public MainPage() { InitializeComponent(); }
}
