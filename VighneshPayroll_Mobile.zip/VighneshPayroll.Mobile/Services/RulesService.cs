using VighneshPayroll.Core;
using VighneshPayroll.Data;

namespace VighneshPayroll.Services;

/// <summary>Effective-dated statutory rules (latest EffectiveFrom on/before the payroll month wins).</summary>
public static class RulesService
{
    public static StatutoryRules For(DateTime month)
    {
        var rules = StatutoryRules.CreateDefault();
        foreach (var key in StatutoryRules.AllKeys)
        {
            var v = Db.Scalar("SELECT RuleValue FROM StatutoryRules WHERE RuleKey=? AND EffectiveFrom<=? ORDER BY EffectiveFrom DESC, Id DESC LIMIT 1",
                key, month);
            if (v != null) rules.Apply(key, Convert.ToDecimal(v, System.Globalization.CultureInfo.InvariantCulture));
        }
        return rules;
    }

    public static string? Save(string key, decimal value, DateTime effectiveFrom, string? notes)
    {
        var err = StatutoryRules.Validate(key, value); if (err != null) return err;
        Db.Execute("INSERT INTO StatutoryRules(RuleKey,RuleValue,EffectiveFrom,Notes) VALUES(?,?,?,?)", key, value, effectiveFrom, notes);
        return null;
    }

    public static List<Row> History() =>
        Db.Query("SELECT * FROM StatutoryRules ORDER BY EffectiveFrom DESC, Id DESC LIMIT 100");
}
