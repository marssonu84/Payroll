using System.Security.Cryptography;
using VighneshPayroll.Data;

namespace VighneshPayroll.Services;

/// <summary>Same PBKDF2$iterations$salt$hash format as the web app's Auth.cs.</summary>
public sealed class AuthService
{
    private const int SaltSize = 16, HashSize = 32, Iterations = 210000;
    private int _failed; private DateTime _lockUntil = DateTime.MinValue;
    private readonly AppState _state;
    public AuthService(AppState state) { _state = state; }

    public bool IsSetupDone() => Convert.ToInt32(Db.Scalar("SELECT COUNT(*) FROM Users")) > 0;

    public static string Hash(string password)
    {
        byte[] salt = RandomNumberGenerator.GetBytes(SaltSize);
        byte[] h = Rfc2898DeriveBytes.Pbkdf2(password, salt, Iterations, HashAlgorithmName.SHA256, HashSize);
        return $"PBKDF2${Iterations}${Convert.ToBase64String(salt)}${Convert.ToBase64String(h)}";
    }

    public static bool Verify(string password, string stored)
    {
        var p = (stored ?? "").Split('$');
        if (p.Length != 4 || p[0] != "PBKDF2" || !int.TryParse(p[1], out int it)) return false;
        try
        {
            byte[] salt = Convert.FromBase64String(p[2]), expected = Convert.FromBase64String(p[3]);
            byte[] actual = Rfc2898DeriveBytes.Pbkdf2(password, salt, it, HashAlgorithmName.SHA256, expected.Length);
            return CryptographicOperations.FixedTimeEquals(actual, expected);
        }
        catch { return false; }
    }

    public static string? ValidatePassword(string pw)
    {
        if (pw.Length < 8) return "Password must be at least 8 characters.";
        if (!pw.Any(char.IsLetter) || !pw.Any(char.IsDigit)) return "Use letters and digits.";
        return null;
    }

    public string? CreateFirstAdmin(string org, string user, string pw)
    {
        if (IsSetupDone()) return "Setup is already complete.";
        if (string.IsNullOrWhiteSpace(org) || string.IsNullOrWhiteSpace(user)) return "Organisation and username are required.";
        var err = ValidatePassword(pw); if (err != null) return err;
        Settings.Set("OrgName", org.Trim());
        Db.Execute("INSERT INTO Users(username,password_hash,IsAdmin,IsActive) VALUES(?,?,1,1)", user.Trim(), Hash(pw));
        Db.Execute("INSERT OR IGNORE INTO Branches(BranchCode) VALUES('MAIN')");
        Audit.Log(user, "SETUP", "First administrator created");
        return null;
    }

    public async Task<string?> LoginAsync(string user, string pw)
    {
        if (DateTime.UtcNow < _lockUntil) return "Too many attempts. Try again in a few minutes.";
        var rows = Db.Query("SELECT * FROM Users WHERE username=? AND IsActive=1", user.Trim());
        bool ok = rows.Count == 1 && await Task.Run(() => Verify(pw, rows[0].S("password_hash")));
        if (!ok)
        {
            if (++_failed >= 5) { _lockUntil = DateTime.UtcNow.AddMinutes(5); _failed = 0; }
            Audit.Log(user, "LOGIN_FAILED");
            return "Invalid username or password.";
        }
        _failed = 0;
        _state.SignIn(rows[0].S("username"), rows[0].B("IsAdmin"), rows[0].B("CanBackup"), rows[0].B("CanRestore"));
        Audit.Log(user, "LOGIN");
        return null;
    }

    public string? ChangePassword(string user, string oldPw, string newPw)
    {
        var rows = Db.Query("SELECT * FROM Users WHERE username=?", user);
        if (rows.Count != 1 || !Verify(oldPw, rows[0].S("password_hash"))) return "Current password is incorrect.";
        var err = ValidatePassword(newPw); if (err != null) return err;
        Db.Execute("UPDATE Users SET password_hash=? WHERE username=?", Hash(newPw), user);
        Audit.Log(user, "PASSWORD_CHANGED");
        return null;
    }
}
