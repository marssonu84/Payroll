using VighneshPayroll.Data;

namespace VighneshPayroll.Services;

public sealed class AttendanceEntry
{
    public int EmployeeID { get; set; }
    public string Name { get; set; } = "";
    public int Lates { get; set; }
    public int Permissions { get; set; }
    public decimal DeductionDays { get; set; }
    public string Remarks { get; set; } = "";
}

public static class AttendanceService
{
    public static List<AttendanceEntry> Load(DateTime month)
    {
        month = PayrollService.MonthStart(month);
        return Db.Query(@"SELECT E.EmployeeID, E.EmployeeName, A.Lates, A.Permissions, A.DeductionDays, A.Remarks
                          FROM Employees E LEFT JOIN MonthlyAttendance A ON A.EmployeeID=E.EmployeeID AND A.AttendanceMonth=?
                          WHERE E.IsActive=1 ORDER BY E.EmployeeName", month)
            .Select(r => new AttendanceEntry { EmployeeID = r.I("EmployeeID"), Name = r.S("EmployeeName"), Lates = r.I("Lates"),
                Permissions = r.I("Permissions"), DeductionDays = r.D("DeductionDays"), Remarks = r.S("Remarks") }).ToList();
    }

    public static string? Save(DateTime month, List<AttendanceEntry> entries)
    {
        month = PayrollService.MonthStart(month);
        int days = DateTime.DaysInMonth(month.Year, month.Month);
        foreach (var e in entries)
            if (e.DeductionDays < 0 || e.DeductionDays > days) return $"{e.Name}: deduction days must be between 0 and {days}.";
        Db.Transaction(exec =>
        {
            foreach (var e in entries)
                exec(@"INSERT INTO MonthlyAttendance(EmployeeID,AttendanceMonth,Lates,Permissions,DeductionDays,Remarks) VALUES(?,?,?,?,?,?)
                       ON CONFLICT(EmployeeID,AttendanceMonth) DO UPDATE SET Lates=excluded.Lates, Permissions=excluded.Permissions,
                       DeductionDays=excluded.DeductionDays, Remarks=excluded.Remarks",
                    new object?[] { e.EmployeeID, month, e.Lates, e.Permissions, e.DeductionDays, e.Remarks });
        });
        return null;
    }
}
