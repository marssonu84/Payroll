using System.Globalization;
using VighneshPayroll.Data;

namespace VighneshPayroll.Services;

public sealed class EmployeeModel
{
    public int EmployeeID { get; set; }
    public string EmployeeCode { get; set; } = "";
    public string EmployeeName { get; set; } = "";
    public string Designation { get; set; } = "";
    public string BranchCode { get; set; } = "MAIN";
    public DateTime? DateOfJoining { get; set; }
    public bool PFMember { get; set; }
    public bool ESIMember { get; set; }
    public string UANNo { get; set; } = "";
    public string ESINo { get; set; } = "";
    public string BankAccount { get; set; } = "";
    public string BankName { get; set; } = "";
    public string IFSCCode { get; set; } = "";
    public decimal StandardSalaryPrev { get; set; }
    public decimal IncrementAmount { get; set; }
    public decimal SalaryAdjustment { get; set; }
    public bool IsActive { get; set; } = true;

    public static EmployeeModel From(Row r) => new()
    {
        EmployeeID = r.I("EmployeeID"), EmployeeCode = r.S("EmployeeCode"), EmployeeName = r.S("EmployeeName"),
        Designation = r.S("Designation"), BranchCode = r.S("BranchCode"), DateOfJoining = r.Dt("DateOfJoining"),
        PFMember = r.B("PFMember"), ESIMember = r.B("ESIMember"), UANNo = r.S("UANNo"), ESINo = r.S("ESINo"),
        BankAccount = r.S("BankAccount"), BankName = r.S("BankName"), IFSCCode = r.S("IFSCCode"),
        StandardSalaryPrev = r.D("StandardSalaryPrev"), IncrementAmount = r.D("IncrementAmount"),
        SalaryAdjustment = r.D("SalaryAdjustment"), IsActive = r.B("IsActive")
    };
}

public static class EmployeeService
{
    public static List<EmployeeModel> List(string? search = null, bool activeOnly = false)
    {
        var sql = "SELECT * FROM Employees WHERE 1=1";
        var args = new List<object?>();
        if (activeOnly) sql += " AND IsActive=1";
        if (!string.IsNullOrWhiteSpace(search))
        {
            sql += " AND (EmployeeName LIKE ? OR EmployeeCode LIKE ? OR Designation LIKE ?)";
            var like = "%" + search.Trim() + "%"; args.Add(like); args.Add(like); args.Add(like);
        }
        sql += " ORDER BY EmployeeName";
        return Db.Query(sql, args.ToArray()).Select(EmployeeModel.From).ToList();
    }

    public static EmployeeModel? Get(int id) =>
        Db.Query("SELECT * FROM Employees WHERE EmployeeID=?", id).Select(EmployeeModel.From).FirstOrDefault();

    public static string? Validate(EmployeeModel e)
    {
        if (string.IsNullOrWhiteSpace(e.EmployeeName)) return "Employee name is required.";
        if (string.IsNullOrWhiteSpace(e.EmployeeCode)) return "Employee code is required.";
        if (string.IsNullOrWhiteSpace(e.BranchCode)) return "Branch is required.";
        if (e.StandardSalaryPrev < 0 || e.IncrementAmount < 0) return "Salary values cannot be negative.";
        var dup = Db.Scalar("SELECT COUNT(*) FROM Employees WHERE EmployeeCode=? AND EmployeeID<>?", e.EmployeeCode.Trim(), e.EmployeeID);
        if (Convert.ToInt32(dup) > 0) return "Employee code already exists.";
        return null;
    }

    public static string? Save(EmployeeModel e)
    {
        var err = Validate(e); if (err != null) return err;
        Db.Execute("INSERT OR IGNORE INTO Branches(BranchCode) VALUES(?)", e.BranchCode.Trim());
        if (e.EmployeeID == 0)
            Db.Insert(@"INSERT INTO Employees(EmployeeCode,EmployeeName,Designation,BranchCode,DateOfJoining,PFMember,ESIMember,UANNo,ESINo,
                BankAccount,BankName,IFSCCode,StandardSalaryPrev,IncrementAmount,SalaryAdjustment,IsActive) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                e.EmployeeCode.Trim(), e.EmployeeName.Trim(), e.Designation, e.BranchCode.Trim(), e.DateOfJoining, e.PFMember, e.ESIMember,
                e.UANNo, e.ESINo, e.BankAccount, e.BankName, e.IFSCCode, e.StandardSalaryPrev, e.IncrementAmount, e.SalaryAdjustment, e.IsActive);
        else
            Db.Execute(@"UPDATE Employees SET EmployeeCode=?,EmployeeName=?,Designation=?,BranchCode=?,DateOfJoining=?,PFMember=?,ESIMember=?,
                UANNo=?,ESINo=?,BankAccount=?,BankName=?,IFSCCode=?,StandardSalaryPrev=?,IncrementAmount=?,SalaryAdjustment=?,IsActive=? WHERE EmployeeID=?",
                e.EmployeeCode.Trim(), e.EmployeeName.Trim(), e.Designation, e.BranchCode.Trim(), e.DateOfJoining, e.PFMember, e.ESIMember,
                e.UANNo, e.ESINo, e.BankAccount, e.BankName, e.IFSCCode, e.StandardSalaryPrev, e.IncrementAmount, e.SalaryAdjustment, e.IsActive, e.EmployeeID);
        return null;
    }

    /// <summary>Employees with payroll history are deactivated rather than deleted.</summary>
    public static string Remove(int id)
    {
        bool used = Convert.ToInt32(Db.Scalar("SELECT (SELECT COUNT(*) FROM Payroll WHERE EmployeeID=?)+(SELECT COUNT(*) FROM Loans WHERE EmployeeID=?)", id, id)) > 0;
        if (used) { Db.Execute("UPDATE Employees SET IsActive=0 WHERE EmployeeID=?", id); return "Employee has payroll/loan history, so was marked inactive."; }
        Db.Execute("DELETE FROM MonthlyAttendance WHERE EmployeeID=?", id);
        Db.Execute("DELETE FROM Employees WHERE EmployeeID=?", id);
        return "Employee deleted.";
    }

    // ---- CSV import: same column headings as Employee_Data_Upload_Template.xlsx (Save As CSV) ----
    public static (int added, int updated, List<string> errors) ImportCsv(Stream csv)
    {
        var rows = Csv.Parse(csv);
        int added = 0, updated = 0; var errors = new List<string>();
        if (rows.Count < 2) { errors.Add("File has no data rows."); return (0, 0, errors); }
        var h = rows[0].Select(x => x.Replace("*", "").Trim().ToLowerInvariant()).ToList();
        int Col(params string[] names) { foreach (var n in names) { int i = h.FindIndex(x => x.StartsWith(n)); if (i >= 0) return i; } return -1; }
        int cCode = Col("employee code"), cName = Col("employee name"), cDes = Col("designation"), cBr = Col("branch code"), cDoj = Col("date of joining"),
            cPf = Col("pf member"), cEsi = Col("esi member"), cUan = Col("uan"), cEsiNo = Col("esi no"), cAcc = Col("bank account"),
            cBank = Col("bank name"), cIfsc = Col("ifsc"), cSal = Col("previous standard"), cInc = Col("increment"), cAdj = Col("salary adjustment"), cAct = Col("active");
        if (cCode < 0 || cName < 0 || cBr < 0) { errors.Add("Required columns missing: Employee Code, Employee Name, Branch Code."); return (0, 0, errors); }
        string G(List<string> r, int c) => c >= 0 && c < r.Count ? r[c].Trim() : "";
        bool Yes(string s) => s.Length > 0 && (s.StartsWith("y", StringComparison.OrdinalIgnoreCase) || s == "1" || s.Equals("true", StringComparison.OrdinalIgnoreCase));
        decimal M(string s) => decimal.TryParse(s, NumberStyles.Number, CultureInfo.InvariantCulture, out var d) ? d : 0m;

        for (int i = 1; i < rows.Count; i++)
        {
            var r = rows[i];
            if (r.All(string.IsNullOrWhiteSpace)) continue;
            var e = new EmployeeModel
            {
                EmployeeCode = G(r, cCode), EmployeeName = G(r, cName), Designation = G(r, cDes), BranchCode = G(r, cBr),
                PFMember = Yes(G(r, cPf)), ESIMember = Yes(G(r, cEsi)), UANNo = G(r, cUan), ESINo = G(r, cEsiNo),
                BankAccount = G(r, cAcc), BankName = G(r, cBank), IFSCCode = G(r, cIfsc),
                StandardSalaryPrev = M(G(r, cSal)), IncrementAmount = M(G(r, cInc)), SalaryAdjustment = M(G(r, cAdj)),
                IsActive = cAct < 0 || G(r, cAct) == "" || Yes(G(r, cAct))
            };
            if (DateTime.TryParse(G(r, cDoj), CultureInfo.GetCultureInfo("en-IN"), DateTimeStyles.None, out var dj)) e.DateOfJoining = dj;
            var existing = Db.Scalar("SELECT EmployeeID FROM Employees WHERE EmployeeCode=?", e.EmployeeCode);
            bool upd = existing != null;
            if (upd) e.EmployeeID = Convert.ToInt32(existing);
            var err = Save(e);
            if (err != null) errors.Add($"Row {i + 1}: {err}"); else if (upd) updated++; else added++;
        }
        return (added, updated, errors);
    }
}
