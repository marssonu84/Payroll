using System.Text;

namespace VighneshPayroll.Services;

public static class Csv
{
    public static List<List<string>> Parse(Stream s)
    {
        using var rd = new StreamReader(s, Encoding.UTF8, true);
        var text = rd.ReadToEnd();
        var rows = new List<List<string>>(); var row = new List<string>(); var cur = new StringBuilder(); bool q = false;
        for (int i = 0; i < text.Length; i++)
        {
            char c = text[i];
            if (q) { if (c == '"') { if (i + 1 < text.Length && text[i + 1] == '"') { cur.Append('"'); i++; } else q = false; } else cur.Append(c); }
            else if (c == '"') q = true;
            else if (c == ',') { row.Add(cur.ToString()); cur.Clear(); }
            else if (c == '\n' || c == '\r') { if (c == '\r' && i + 1 < text.Length && text[i + 1] == '\n') i++; row.Add(cur.ToString()); cur.Clear(); rows.Add(row); row = new(); }
            else cur.Append(c);
        }
        if (cur.Length > 0 || row.Count > 0) { row.Add(cur.ToString()); rows.Add(row); }
        return rows;
    }

    public static string Escape(string? v)
    {
        v ??= "";
        // neutralise spreadsheet formula injection
        if (v.Length > 0 && "=+-@".IndexOf(v[0]) >= 0 && !decimal.TryParse(v, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out _)) v = "'" + v;
        return v.IndexOfAny(new[] { ',', '"', '\n', '\r' }) >= 0 ? "\"" + v.Replace("\"", "\"\"") + "\"" : v;
    }

    public static string Build(IEnumerable<string> header, IEnumerable<IEnumerable<string>> rows)
    {
        var sb = new StringBuilder();
        sb.AppendLine(string.Join(",", header.Select(Escape)));
        foreach (var r in rows) sb.AppendLine(string.Join(",", r.Select(Escape)));
        return sb.ToString();
    }
}
