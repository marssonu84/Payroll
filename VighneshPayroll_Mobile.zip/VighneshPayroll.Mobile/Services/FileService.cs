using Microsoft.Data.Sqlite;
using VighneshPayroll.Data;

namespace VighneshPayroll.Services;

/// <summary>Share/export CSV files and back up / restore the on-phone database.</summary>
public static class FileService
{
    public static async Task ShareTextFileAsync(string fileName, string content, string title)
    {
        var path = Path.Combine(FileSystem.CacheDirectory, fileName);
        await File.WriteAllTextAsync(path, content, new System.Text.UTF8Encoding(true));
        await Share.Default.RequestAsync(new ShareFileRequest { Title = title, File = new ShareFile(path) });
    }

    public static async Task<string> BackupAsync(string? user)
    {
        Db.Init();
        var path = Path.Combine(FileSystem.CacheDirectory, $"payroll-backup-{DateTime.Now:yyyyMMdd-HHmm}.db3");
        if (File.Exists(path)) File.Delete(path);
        using (var con = Db.Open())
        using (var cmd = con.CreateCommand())
        {
            cmd.CommandText = "VACUUM INTO @p"; // consistent snapshot even while the DB is open
            cmd.Parameters.AddWithValue("@p", path);
            cmd.ExecuteNonQuery();
        }
        Audit.Log(user, "BACKUP");
        await Share.Default.RequestAsync(new ShareFileRequest { Title = "Save payroll backup", File = new ShareFile(path) });
        return path;
    }

    public static async Task<string?> RestoreAsync(string? user, bool keepCurrentUsers = false)
    {
        var pick = await FilePicker.Default.PickAsync(new PickOptions { PickerTitle = "Choose a payroll backup (.db3)" });
        if (pick == null) return "Cancelled.";
        var temp = Path.Combine(FileSystem.CacheDirectory, "restore.db3");
        using (var src = await pick.OpenReadAsync())
        using (var dst = File.Create(temp)) await src.CopyToAsync(dst);

        try // validate before touching the live database
        {
            using var con = new SqliteConnection($"Data Source={temp};Mode=ReadOnly");
            con.Open();
            using var cmd = con.CreateCommand();
            cmd.CommandText = "SELECT COUNT(*) FROM sqlite_master WHERE name IN ('Employees','Payroll','Users')";
            if (Convert.ToInt32(cmd.ExecuteScalar()) != 3) return "That file is not a Vighnesh Payroll backup.";
        }
        catch { return "That file could not be read as a backup."; }
        finally { SqliteConnection.ClearAllPools(); }

        // A non-admin restore must never be able to bring in its own accounts/permissions.
        var keptUsers = keepCurrentUsers ? Db.Query("SELECT * FROM Users") : null;
        var safety = Db.FilePath + ".before-restore";
        if (File.Exists(Db.FilePath)) File.Copy(Db.FilePath, safety, true);
        File.Copy(temp, Db.FilePath, true);
        foreach (var ext in new[] { "-wal", "-shm" }) { var f = Db.FilePath + ext; if (File.Exists(f)) File.Delete(f); }
        Schema.EnsureCreated();
        if (keptUsers != null)
        {
            Db.Execute("DELETE FROM Users");
            foreach (var u in keptUsers)
                Db.Execute("INSERT INTO Users(id,username,password_hash,IsAdmin,IsActive,CanBackup,CanRestore) VALUES(?,?,?,?,?,?,?)",
                    u.I("id"), u.S("username"), u.S("password_hash"), u.B("IsAdmin"), u.B("IsActive"), u.B("CanBackup"), u.B("CanRestore"));
        }
        Audit.Log(user, keptUsers != null ? "RESTORE (accounts kept)" : "RESTORE");
        return null;
    }
}
