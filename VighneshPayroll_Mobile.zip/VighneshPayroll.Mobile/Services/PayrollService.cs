using VighneshPayroll.Core;
using VighneshPayroll.Data;

namespace VighneshPayroll.Services;

public sealed class PayrollLine
{
    public EmployeeModel Employee { get; set; } = new();
    public decimal Leaves { get; set; }
    public bool HasAttendance { get; set; }
    public decimal LoanDeduction { get; set; }
    public decimal Other { get; set; }
    public PayrollResult Result { get; set; } = new();
}

public static class PayrollService
{
    public static DateTime MonthStart(DateTime d) => new(d.Year, d.Month, 1);

    public static decimal LoanDeductionForMonth(int empId, DateTime month)
    {
        var start = MonthStart(month);
        var v = Db.Scalar("SELECT COALESCE(SUM(Deduction),0) FROM Loans WHERE EmployeeID=? AND TxnDate>=? AND TxnDate<?", empId, start, start.AddMonths(1));
        return Convert.ToDecimal(v ?? 0m, System.Globalization.CultureInfo.InvariantCulture);
    }

    public static PayrollResult Compute(EmployeeModel e, DateTime month, decimal leaves, decimal adv, decimal other, StatutoryRules rules) =>
        PayrollCalculator.Calculate(e.StandardSalaryPrev, e.IncrementAmount, e.SalaryAdjustment,
            DateTime.DaysInMonth(month.Year, month.Month), leaves, e.PFMember, e.ESIMember, adv, other, rules);

    /// <summary>Preview payroll for all active employees. "other" keeps values already typed by the user.</summary>
    public static List<PayrollLine> Preview(DateTime month, IDictionary<int, decimal>? other = null)
    {
        month = MonthStart(month);
        var rules = RulesService.For(month);
        var lines = new List<PayrollLine>();
        foreach (var e in EmployeeService.List(activeOnly: true))
        {
            var att = Db.Query("SELECT DeductionDays FROM MonthlyAttendance WHERE EmployeeID=? AND AttendanceMonth=?", e.EmployeeID, month);
            decimal leaves = att.Count == 1 ? att[0].D("DeductionDays") : 0m;
            decimal adv = LoanDeductionForMonth(e.EmployeeID, month);
            decimal oth = other != null && other.TryGetValue(e.EmployeeID, out var o) ? o : 0m;
            lines.Add(new PayrollLine
            {
                Employee = e, Leaves = leaves, HasAttendance = att.Count == 1, LoanDeduction = adv, Other = oth,
                Result = Compute(e, month, leaves, adv, oth, rules)
            });
        }
        return lines;
    }

    public static void Save(DateTime month, List<PayrollLine> lines, string? user)
    {
        month = MonthStart(month);
        int days = DateTime.DaysInMonth(month.Year, month.Month);
        Db.Transaction(exec =>
        {
            foreach (var l in lines)
            {
                var r = l.Result;
                exec("DELETE FROM Payroll WHERE EmployeeID=? AND SalaryMonth=?", new object?[] { l.Employee.EmployeeID, month });
                exec(@"INSERT INTO Payroll(EmployeeID,SalaryMonth,DaysInMonth,Leaves,StandardSalary,LOP,GrossSalary,Basic,DA,PF,ESI,PT,
                        SalaryAdvance,OtherDeductions,TotalDeductions,NetPay,CreatedOn) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    new object?[] { l.Employee.EmployeeID, month, days, l.Leaves, r.StandardSalary, r.Lop, r.Gross, r.Basic, r.Da, r.Pf, r.Esi, r.Pt,
                        l.LoanDeduction, l.Other, r.TotalDeductions, r.NetPay, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") });
            }
        });
        Audit.Log(user, "PAYROLL_PROCESSED", $"{month:yyyy-MM}, {lines.Count} employees");
    }

    public static List<Row> Saved(DateTime month) =>
        Db.Query(@"SELECT P.*, E.EmployeeName, E.EmployeeCode, E.Designation, E.BranchCode, E.BankAccount, E.BankName, E.IFSCCode, E.UANNo, E.ESINo
                   FROM Payroll P JOIN Employees E ON E.EmployeeID=P.EmployeeID WHERE P.SalaryMonth=? ORDER BY E.EmployeeName", MonthStart(month));

    public static List<DateTime> ProcessedMonths() =>
        Db.Query("SELECT DISTINCT SalaryMonth FROM Payroll ORDER BY SalaryMonth DESC").Select(r => r.Dt("SalaryMonth")!.Value).ToList();
}
