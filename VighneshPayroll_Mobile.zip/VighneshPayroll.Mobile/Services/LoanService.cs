using VighneshPayroll.Data;

namespace VighneshPayroll.Services;

public static class LoanService
{
    public static List<Row> List(int empId) =>
        Db.Query("SELECT * FROM Loans WHERE EmployeeID=? ORDER BY TxnDate, LoanID", empId);

    public static List<Row> Balances() =>
        Db.Query(@"SELECT E.EmployeeID, E.EmployeeName,
                    (SELECT NetBalance FROM Loans L WHERE L.EmployeeID=E.EmployeeID ORDER BY TxnDate DESC, LoanID DESC LIMIT 1) AS Balance
                   FROM Employees E WHERE EXISTS (SELECT 1 FROM Loans L WHERE L.EmployeeID=E.EmployeeID) ORDER BY E.EmployeeName");

    public static decimal CurrentBalance(int empId)
    {
        var v = Db.Scalar("SELECT NetBalance FROM Loans WHERE EmployeeID=? ORDER BY TxnDate DESC, LoanID DESC LIMIT 1", empId);
        return v == null ? 0m : Convert.ToDecimal(v, System.Globalization.CultureInfo.InvariantCulture);
    }

    public static string? Add(int empId, DateTime date, decimal availed, decimal deduction, string? remarks)
    {
        if (availed < 0 || deduction < 0) return "Amounts cannot be negative.";
        if (availed == 0 && deduction == 0) return "Enter a loan amount or a deduction.";
        decimal opening = CurrentBalance(empId);
        if (deduction > opening + availed) return "Deduction cannot be greater than the available loan balance.";
        Db.Execute("INSERT INTO Loans(EmployeeID,TxnDate,OpeningBalance,LoanAvailed,Deduction,NetBalance,Remarks) VALUES(?,?,?,?,?,?,?)",
            empId, date, opening, availed, deduction, opening + availed - deduction, remarks);
        Recalculate(empId);
        return null;
    }

    public static string? Delete(int loanId)
    {
        var r = Db.Query("SELECT EmployeeID FROM Loans WHERE LoanID=?", loanId);
        if (r.Count == 0) return "Not found.";
        Db.Execute("DELETE FROM Loans WHERE LoanID=?", loanId);
        Recalculate(r[0].I("EmployeeID"));
        return null;
    }

    /// <summary>Rebuilds running balances in date order (mirrors Loans.aspx.cs RecalculateLoanBalances).</summary>
    public static void Recalculate(int empId)
    {
        var rows = List(empId);
        decimal bal = 0m;
        Db.Transaction(exec =>
        {
            foreach (var r in rows)
            {
                decimal net = bal + r.D("LoanAvailed") - r.D("Deduction");
                exec("UPDATE Loans SET OpeningBalance=?, NetBalance=? WHERE LoanID=?", new object?[] { bal, net, r.I("LoanID") });
                bal = net;
            }
        });
    }
}
