namespace VighneshPayroll.Services;

public static class ExitService
{
    /// <summary>Signs out (clears the in-memory session) and closes the app completely.</summary>
    public static void Exit(AppState state)
    {
        state.SignOut();
#if ANDROID
        var activity = Platform.CurrentActivity;
        if (activity != null) { activity.FinishAndRemoveTask(); return; }
#endif
        Application.Current?.Quit();
    }
}
