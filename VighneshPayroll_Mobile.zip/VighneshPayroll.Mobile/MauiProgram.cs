using Microsoft.Extensions.Logging;
using VighneshPayroll.Data;
using VighneshPayroll.Services;

namespace VighneshPayroll;

public static class MauiProgram
{
    public static MauiApp CreateMauiApp()
    {
        var builder = MauiApp.CreateBuilder();
        builder.UseMauiApp<App>();
        builder.Services.AddMauiBlazorWebView();
        builder.Services.AddSingleton<AppState>();
        builder.Services.AddSingleton<AuthService>();
#if DEBUG
        builder.Services.AddBlazorWebViewDeveloperTools();
        builder.Logging.AddDebug();
#endif
        Db.Init();
        Schema.EnsureCreated(); // creates empsalary.db3 in app-private storage on first launch
        return builder.Build();
    }
}
