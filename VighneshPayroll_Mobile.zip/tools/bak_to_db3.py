#!/usr/bin/env python3
"""
Vighnesh Payroll - SQL Server .bak  ->  phone-app .db3 converter.

Reads the raw data pages of an UNCOMPRESSED, UNENCRYPTED native SQL Server full backup
(no SQL Server needed) and writes a SQLite file that the mobile app can restore
(More -> Backup & restore).

Usage:  python3 bak_to_db3.py  input.bak  output.db3  [--tenant N]
"""
import sys, struct, sqlite3, datetime, collections, os

PAGE = 8192
VAR_TYPES = {231, 167, 165, 173, 99, 35, 34, 241, 239}
FIXED_SIZE = {56: 4, 127: 8, 52: 2, 48: 1, 40: 3, 61: 8, 58: 4, 60: 8, 62: 8, 59: 4, 36: 16, 122: 4}

def log(*a): print(*a, flush=True)

# ------------------------------------------------------------------ page discovery
def valid_page(d, o):
    if o < 0 or o + PAGE > len(d): return False
    if d[o] != 1 or d[o+1] not in (1, 2, 3, 4, 8, 9, 10, 11, 13, 15, 16, 17): return False
    if struct.unpack_from('<H', d, o+36)[0] not in (1, 2, 3, 4): return False
    if struct.unpack_from('<I', d, o+32)[0] > 5_000_000: return False
    if struct.unpack_from('<H', d, o+22)[0] > 4000: return False
    if struct.unpack_from('<H', d, o+30)[0] > PAGE: return False
    return True

def load_pages(d):
    cands = [o for o in range(0, len(d) - PAGE + 1) if d[o] == 1 and valid_page(d, o)]
    if not cands:
        raise SystemExit("No SQL Server data pages found. The backup is probably COMPRESSED or ENCRYPTED. "
                         "Create a new backup WITHOUT compression (WITH NO_COMPRESSION) and try again.")
    align = collections.Counter(o % PAGE for o in cands)
    keep = {a for a, n in align.items() if n >= 8}
    if not keep: keep = {align.most_common(1)[0][0]}
    pages = {}
    for o in sorted(cands):
        if o % PAGE in keep:
            p = d[o:o+PAGE]
            key = (struct.unpack_from('<H', p, 36)[0], struct.unpack_from('<I', p, 32)[0])
            pages[key] = p            # later copy of the same page wins
    log(f"Found {len(pages)} database pages (alignment {sorted(keep)}).")
    return list(pages.values())

# ------------------------------------------------------------------ record parsing
def slot_offsets(p):
    n = struct.unpack_from('<H', p, 22)[0]
    for i in range(n):
        off = struct.unpack_from('<H', p, PAGE - 2*(i+1))[0]
        if 96 <= off < PAGE: yield off

def parse_record(p, off):
    try:
        s0 = p[off]
        if ((s0 >> 1) & 7) not in (0, 1): return None
        fend = struct.unpack_from('<H', p, off+2)[0]
        ncols = struct.unpack_from('<H', p, off+fend)[0]
        nb = (ncols + 7) // 8
        bitmap = p[off+fend+2: off+fend+2+nb]
        pos = off + fend + 2 + nb
        var = []
        if s0 & 0x20:
            nvar = struct.unpack_from('<H', p, pos)[0]
            offs = [struct.unpack_from('<H', p, pos+2+2*k)[0] & 0x7fff for k in range(nvar)]
            prev = pos + 2 + 2*nvar
            for e in offs:
                end = off + e
                var.append(p[prev:end] if end >= prev else b'')
                if end >= prev: prev = end
        return dict(fixed=p[off+4: off+fend], bitmap=bitmap, var=var, ncols=ncols)
    except Exception:
        return None

def is_null(r, idx):
    return idx < r['ncols'] and idx//8 < len(r['bitmap']) and (r['bitmap'][idx//8] >> (idx % 8)) & 1

class Backup:
    def __init__(self, data):
        self.pages = load_pages(data)
        self.by_obj = collections.defaultdict(list)
        for p in self.pages:
            if p[1] == 1:
                self.by_obj[(struct.unpack_from('<I', p, 24)[0], struct.unpack_from('<H', p, 6)[0])].append(p)
        self.tables = {}
        self.cols = collections.defaultdict(list)
        self._catalog()

    def raw_rows(self, hdr_obj, idxs):
        for (o, i), plist in self.by_obj.items():
            if o == hdr_obj and i in idxs:
                for p in plist:
                    for off in slot_offsets(p):
                        r = parse_record(p, off)
                        if r: yield r

    def sys_rows(self, obj):
        # system base tables: header object id == catalog object id, index id 0 or 1
        return self.raw_rows(obj, (0, 1))

    def _catalog(self):
        for r in self.sys_rows(34):               # sysschobjs
            f = r['fixed']
            if len(f) < 15 or not r['var']: continue
            oid = struct.unpack_from('<i', f, 0)[0]
            if f[13:15] == b'U ':
                self.tables[oid] = r['var'][0].decode('utf-16le', 'ignore')
        for r in self.sys_rows(41):               # syscolpars
            f = r['fixed']
            if len(f) < 19 or not r['var']: continue
            oid = struct.unpack_from('<i', f, 0)[0]
            if oid not in self.tables: continue
            colid = struct.unpack_from('<i', f, 6)[0]
            self.cols[oid].append((colid, r['var'][0].decode('utf-16le', 'ignore'), f[10],
                                   struct.unpack_from('<h', f, 15)[0], f[17], f[18]))
        for oid in self.cols: self.cols[oid].sort()
        rowsets = {}
        for r in self.sys_rows(5):                # sysrowsets
            f = r['fixed']
            if len(f) >= 17:
                rowsets[struct.unpack_from('<q', f, 0)[0]] = (struct.unpack_from('<i', f, 9)[0], struct.unpack_from('<i', f, 13)[0])
        self.data_objs = collections.defaultdict(set)
        for r in self.sys_rows(7):                # sysallocunits
            f = r['fixed']
            if len(f) < 17: continue
            auid = struct.unpack_from('<q', f, 0)[0]; typ = f[8]; owner = struct.unpack_from('<q', f, 9)[0]
            if typ == 1 and owner in rowsets:
                major, minor = rowsets[owner]
                if major in self.tables and minor in (0, 1):
                    self.data_objs[major].add((auid >> 16) & 0xffffffff)
        log(f"Catalog: {len(self.tables)} user tables.")

    def table(self, name):
        oid = next((o for o, n in self.tables.items() if n.lower() == name.lower()), None)
        if oid is None: return None
        cl = self.cols[oid]
        fixed = [(i, c) for i, c in enumerate(cl) if c[2] not in VAR_TYPES]
        var = [(i, c) for i, c in enumerate(cl) if c[2] in VAR_TYPES]
        out = []
        for ho in self.data_objs.get(oid, ()):
            for (o, i), plist in self.by_obj.items():
                if o != ho: continue
                for p in plist:
                    for off in slot_offsets(p):
                        r = parse_record(p, off)
                        if not r: continue
                        try: out.append(self._decode(r, fixed, var))
                        except Exception: continue
        return out

    @staticmethod
    def _decode(r, fixed, var):
        f = r['fixed']; pos = 0; vals = {}; bitbyte = 0; bitn = 8
        for i, (colid, name, xt, ln, prec, scale) in fixed:
            if xt == 104:
                if bitn >= 8:
                    bitbyte = f[pos] if pos < len(f) else 0; pos += 1; bitn = 0
                v = (bitbyte >> bitn) & 1; bitn += 1
            else:
                bitn = 8
                if xt in (106, 108):
                    sz = 5 if prec <= 9 else 9 if prec <= 19 else 13 if prec <= 28 else 17
                    raw = f[pos:pos+sz]; pos += sz
                    if len(raw) < sz: v = None
                    else:
                        n = int.from_bytes(raw[1:], 'little'); v = (n if raw[0] == 1 else -n) / (10 ** scale)
                else:
                    sz = FIXED_SIZE.get(xt) or (ln if ln > 0 else 0)
                    raw = f[pos:pos+sz]; pos += sz
                    if len(raw) < sz: v = None
                    elif xt in (56, 127, 52, 48): v = int.from_bytes(raw, 'little', signed=True)
                    elif xt == 40: v = (datetime.date(1, 1, 1) + datetime.timedelta(days=int.from_bytes(raw, 'little'))).isoformat()
                    elif xt == 61:
                        days = int.from_bytes(raw[4:], 'little', signed=True); tk = int.from_bytes(raw[:4], 'little')
                        v = (datetime.datetime(1900, 1, 1) + datetime.timedelta(days=days, seconds=tk/300)).strftime('%Y-%m-%d %H:%M:%S')
                    elif xt == 62: v = struct.unpack('<d', raw)[0]
                    else: v = raw.hex()
            vals[name] = None if is_null(r, i) else v
        for k, (i, c) in enumerate(var):
            raw = r['var'][k] if k < len(r['var']) else b''
            if is_null(r, i): v = None
            elif c[2] in (231, 99): v = raw.decode('utf-16le', 'ignore')
            elif c[2] in (167, 35): v = raw.decode('latin-1')
            else: v = raw.hex()
            vals[c[1]] = v
        return vals

# ------------------------------------------------------------------ output schema (same as the app)
DDL = [
"CREATE TABLE IF NOT EXISTS Settings (Key TEXT PRIMARY KEY, Value TEXT)",
"CREATE TABLE IF NOT EXISTS Users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL UNIQUE COLLATE NOCASE, password_hash TEXT NOT NULL, IsAdmin INTEGER NOT NULL DEFAULT 0, IsActive INTEGER NOT NULL DEFAULT 1)",
"CREATE TABLE IF NOT EXISTS Branches (BranchCode TEXT PRIMARY KEY, IsActive INTEGER NOT NULL DEFAULT 1)",
"""CREATE TABLE IF NOT EXISTS Employees (EmployeeID INTEGER PRIMARY KEY AUTOINCREMENT, EmployeeCode TEXT NULL, EmployeeName TEXT NOT NULL, Designation TEXT NULL, BranchCode TEXT NOT NULL, DateOfJoining TEXT NULL, PFMember INTEGER NOT NULL DEFAULT 0, ESIMember INTEGER NOT NULL DEFAULT 0, UANNo TEXT NULL, ESINo TEXT NULL, BankAccount TEXT NULL, BankName TEXT NULL, IFSCCode TEXT NULL, StandardSalaryPrev REAL NOT NULL DEFAULT 0, IncrementAmount REAL NOT NULL DEFAULT 0, SalaryAdjustment REAL NOT NULL DEFAULT 0, IsActive INTEGER NOT NULL DEFAULT 1)""",
"CREATE TABLE IF NOT EXISTS MonthlyAttendance (EmployeeID INTEGER NOT NULL, AttendanceMonth TEXT NOT NULL, Lates INTEGER NOT NULL DEFAULT 0, Permissions INTEGER NOT NULL DEFAULT 0, DeductionDays REAL NOT NULL DEFAULT 0, Remarks TEXT NULL, PRIMARY KEY (EmployeeID, AttendanceMonth))",
"""CREATE TABLE IF NOT EXISTS Payroll (PayrollID INTEGER PRIMARY KEY AUTOINCREMENT, EmployeeID INTEGER NOT NULL, SalaryMonth TEXT NOT NULL, DaysInMonth INTEGER NOT NULL DEFAULT 30, Leaves REAL NOT NULL DEFAULT 0, StandardSalary REAL NOT NULL DEFAULT 0, LOP REAL NOT NULL DEFAULT 0, GrossSalary REAL NOT NULL DEFAULT 0, Basic REAL NOT NULL DEFAULT 0, DA REAL NOT NULL DEFAULT 0, PF REAL NOT NULL DEFAULT 0, ESI REAL NOT NULL DEFAULT 0, PT REAL NOT NULL DEFAULT 0, SalaryAdvance REAL NOT NULL DEFAULT 0, OtherDeductions REAL NOT NULL DEFAULT 0, TotalDeductions REAL NOT NULL DEFAULT 0, NetPay REAL NOT NULL DEFAULT 0, CreatedOn TEXT NOT NULL DEFAULT (datetime('now')), UNIQUE (EmployeeID, SalaryMonth))""",
"CREATE TABLE IF NOT EXISTS Loans (LoanID INTEGER PRIMARY KEY AUTOINCREMENT, EmployeeID INTEGER NOT NULL, TxnDate TEXT NOT NULL, OpeningBalance REAL NOT NULL DEFAULT 0, LoanAvailed REAL NOT NULL DEFAULT 0, Deduction REAL NOT NULL DEFAULT 0, NetBalance REAL NOT NULL DEFAULT 0, Remarks TEXT NULL)",
"CREATE TABLE IF NOT EXISTS StatutoryRules (Id INTEGER PRIMARY KEY AUTOINCREMENT, RuleKey TEXT NOT NULL, RuleValue REAL NOT NULL, EffectiveFrom TEXT NOT NULL, Notes TEXT NULL, CreatedOn TEXT NOT NULL DEFAULT (datetime('now')))",
"CREATE TABLE IF NOT EXISTS SystemAudit (AuditID INTEGER PRIMARY KEY AUTOINCREMENT, UserName TEXT NULL, ActionName TEXT NOT NULL, Details TEXT NULL, CreatedOn TEXT NOT NULL DEFAULT (datetime('now')))",
"CREATE INDEX IF NOT EXISTS IX_Loans_Emp ON Loans(EmployeeID, TxnDate)",
"CREATE INDEX IF NOT EXISTS IX_Payroll_Month ON Payroll(SalaryMonth)",
]

def s(v): return None if v is None else str(v)
def f(v): return 0.0 if v is None else float(v)
def i(v): return 0 if v is None else int(v)

def convert(bak_path, out_path, tenant=None):
    b = Backup(open(bak_path, 'rb').read())
    T = lambda n: b.table(n) or []
    tenants = T('Tenants')
    if tenants:
        log("Organisations in backup:")
        for t in tenants: log(f"   TenantID {t.get('TenantID')}: {t.get('OrganizationName')}")
    if tenant is None:
        tenant = tenants[0]['TenantID'] if tenants else None
        if len(tenants) > 1: log(f"More than one organisation: using TenantID {tenant}. Use --tenant N to pick another.")
    mine = lambda r: tenant is None or r.get('TenantID') in (None, tenant)

    if os.path.exists(out_path): os.remove(out_path)
    con = sqlite3.connect(out_path)
    for q in DDL: con.execute(q)
    org = next((t['OrganizationName'] for t in tenants if t.get('TenantID') == tenant), None)
    if org: con.execute("INSERT INTO Settings VALUES('OrgName',?)", (org,))
    counts = collections.OrderedDict()

    n = 0
    for u in T('Users'):
        if not mine(u) or not u.get('username') or not u.get('password_hash'): continue
        con.execute("INSERT OR IGNORE INTO Users(id,username,password_hash,IsAdmin,IsActive) VALUES(?,?,?,?,?)",
                    (u['id'], u['username'], u['password_hash'], 1 if (u.get('IsAdmin') or u.get('IsOrgAdmin')) else 0, i(u.get('IsActive', 1)))); n += 1
    counts['Users'] = n
    n = 0
    for r in T('Branches'):
        if mine(r) and r.get('BranchCode'): con.execute("INSERT OR IGNORE INTO Branches VALUES(?,?)", (r['BranchCode'], i(r.get('IsActive', 1)))); n += 1
    counts['Branches'] = n
    emp_ids = set(); n = 0
    for e in T('Employees'):
        if not mine(e) or not e.get('EmployeeName'): continue
        con.execute("""INSERT OR REPLACE INTO Employees(EmployeeID,EmployeeCode,EmployeeName,Designation,BranchCode,DateOfJoining,PFMember,ESIMember,UANNo,ESINo,BankAccount,BankName,IFSCCode,StandardSalaryPrev,IncrementAmount,SalaryAdjustment,IsActive)
                       VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (e['EmployeeID'], e.get('EmployeeCode'), e['EmployeeName'], e.get('Designation'), e.get('BranchCode') or 'MAIN', e.get('DateOfJoining'),
             i(e.get('PFMember')), i(e.get('ESIMember')), e.get('UANNo'), e.get('ESINo'), e.get('BankAccount'), e.get('BankName'), e.get('IFSCCode'),
             f(e.get('StandardSalaryPrev')), f(e.get('IncrementAmount')), f(e.get('SalaryAdjustment')), i(e.get('IsActive', 1))))
        emp_ids.add(e['EmployeeID']); n += 1
    counts['Employees'] = n
    n = 0
    for a in T('AttendanceMonthlyEmployeeSummary'):
        if a.get('EmployeeID') in emp_ids and a.get('AttendanceMonth'):
            con.execute("INSERT OR REPLACE INTO MonthlyAttendance VALUES(?,?,?,?,?,NULL)",
                        (a['EmployeeID'], a['AttendanceMonth'], i(a.get('LateCount')), i(a.get('PermissionCount')), f(a.get('DeductionDays')))); n += 1
    for a in T('PayrollStatementDeductions'):
        if a.get('EmployeeID') in emp_ids and a.get('AttendanceMonth'):
            con.execute("INSERT OR IGNORE INTO MonthlyAttendance VALUES(?,?,?,?,?,NULL)",
                        (a['EmployeeID'], a['AttendanceMonth'], i(a.get('Lates')), i(a.get('Permissions')), f(a.get('DeductionDays')))); n += 1
    counts['Monthly attendance'] = con.execute('SELECT COUNT(*) FROM MonthlyAttendance').fetchone()[0]
    n = 0
    cols = ['PayrollID','EmployeeID','SalaryMonth','DaysInMonth','Leaves','StandardSalary','LOP','GrossSalary','Basic','DA','PF','ESI','PT','SalaryAdvance','OtherDeductions','TotalDeductions','NetPay','CreatedOn']
    for p in T('Payroll'):
        if p.get('EmployeeID') in emp_ids and p.get('SalaryMonth'):
            vals = [p.get(c) for c in cols]
            for k in range(4, 17): vals[k] = f(vals[k])
            vals[3] = i(vals[3]) or 30; vals[17] = vals[17] or datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            con.execute(f"INSERT OR REPLACE INTO Payroll({','.join(cols)}) VALUES({','.join('?'*len(cols))})", vals); n += 1
    counts['Payroll'] = n
    n = 0
    for l in T('Loans'):
        if l.get('EmployeeID') in emp_ids and l.get('TxnDate'):
            con.execute("INSERT OR REPLACE INTO Loans(LoanID,EmployeeID,TxnDate,OpeningBalance,LoanAvailed,Deduction,NetBalance,Remarks) VALUES(?,?,?,?,?,?,?,?)",
                (l['LoanID'], l['EmployeeID'], l['TxnDate'], f(l.get('OpeningBalance')), f(l.get('LoanAvailed')), f(l.get('Deduction')), f(l.get('NetBalance')), l.get('Remarks'))); n += 1
    counts['Loans'] = n
    n = 0
    for r in T('StatutoryRules'):
        if mine(r) and r.get('RuleKey') and r.get('EffectiveFrom'):
            con.execute("INSERT INTO StatutoryRules(RuleKey,RuleValue,EffectiveFrom,Notes,CreatedOn) VALUES(?,?,?,?,?)",
                (r['RuleKey'], f(r.get('RuleValue')), r['EffectiveFrom'], r.get('Notes'), r.get('CreatedOn') or datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))); n += 1
    counts['Statutory rules'] = n
    con.commit()
    ok = con.execute("SELECT COUNT(*) FROM sqlite_master WHERE name IN ('Employees','Payroll','Users')").fetchone()[0] == 3
    con.close()
    log("\nConverted:")
    for k, v in counts.items(): log(f"   {k:20} {v}")
    if not counts['Employees']: log("\nWARNING: no employees were found - check the backup is the right one.")
    if not counts['Users']: log("\nWARNING: no users found - you will need to run first-time setup in the app.")
    log(f"\nWrote {out_path} ({os.path.getsize(out_path)} bytes){'' if ok else '  [STRUCTURE CHECK FAILED]'}")
    return counts

if __name__ == '__main__':
    args = sys.argv[1:]
    tenant = None
    if '--tenant' in args:
        k = args.index('--tenant'); tenant = int(args[k+1]); del args[k:k+2]
    if len(args) != 2: raise SystemExit(__doc__)
    convert(args[0], args[1], tenant)
