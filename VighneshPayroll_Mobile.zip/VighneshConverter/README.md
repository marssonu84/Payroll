# Vighnesh Converter (Android)
.bak (SQL Server) -> .db3 (phone payroll app), and .db3 -> .sql (T-SQL script for SQL Server).
