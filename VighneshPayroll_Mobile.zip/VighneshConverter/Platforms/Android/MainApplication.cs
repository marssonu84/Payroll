using Android.App;
using Android.Runtime;

namespace VighneshConverter;

[Application(AllowBackup = false)] // keep payroll data out of cloud auto-backup
public class MainApplication : MauiApplication
{
    public MainApplication(IntPtr handle, JniHandleOwnership ownership) : base(handle, ownership) { }
    protected override MauiApp CreateMauiApp() => MauiProgram.CreateMauiApp();
}
