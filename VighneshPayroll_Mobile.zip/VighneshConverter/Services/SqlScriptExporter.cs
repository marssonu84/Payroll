using System.Globalization;
using System.Text;
using Microsoft.Data.Sqlite;

namespace VighneshConverter.Services;

/// <summary>
/// Turns the phone-app database (.db3) into a T-SQL script for the Vighnesh Payroll SQL Server database.
/// (A real .bak cannot be produced without SQL Server itself, so the script is the supported way back.)
/// </summary>
public static class SqlScriptExporter
{
    sealed record Spec(string Table, string[] Keys, string[] Cols, bool IdentityInsert, string? ExtraCol = null, string? ExtraVal = null);

    static readonly Spec[] Specs =
    {
        new("Branches", new[] { "BranchCode" }, new[] { "BranchCode", "IsActive" }, false),
        new("Employees", new[] { "EmployeeID" }, new[] { "EmployeeID", "EmployeeCode", "EmployeeName", "Designation", "BranchCode", "DateOfJoining", "PFMember", "ESIMember", "UANNo", "ESINo", "BankAccount", "BankName", "IFSCCode", "StandardSalaryPrev", "IncrementAmount", "SalaryAdjustment", "IsActive" }, true),
        new("Payroll", new[] { "EmployeeID", "SalaryMonth" }, new[] { "EmployeeID", "SalaryMonth", "DaysInMonth", "Leaves", "StandardSalary", "LOP", "GrossSalary", "Basic", "DA", "PF", "ESI", "PT", "SalaryAdvance", "OtherDeductions", "TotalDeductions", "NetPay", "CreatedOn" }, false),
        new("Loans", new[] { "LoanID" }, new[] { "LoanID", "EmployeeID", "TxnDate", "OpeningBalance", "LoanAvailed", "Deduction", "NetBalance", "Remarks" }, true),
        new("StatutoryRules", new[] { "Id" }, new[] { "Id", "RuleKey", "RuleValue", "EffectiveFrom", "Notes", "CreatedOn" }, true, "CreatedBy", "N'Mobile app'"),
    };

    static string Lit(object? v, string col)
    {
        if (v == null || v is DBNull) return "NULL";
        switch (v)
        {
            case long l: return l.ToString(CultureInfo.InvariantCulture);
            case int i: return i.ToString(CultureInfo.InvariantCulture);
            case double d: return d.ToString("R", CultureInfo.InvariantCulture);
            default:
                var s = Convert.ToString(v, CultureInfo.InvariantCulture) ?? "";
                if (col == "CreatedOn" && s.Length == 19 && s[10] == ' ') s = s.Replace(' ', 'T');
                return "N'" + s.Replace("'", "''") + "'";
        }
    }

    public static (string script, string summary) Export(string db3Path, int tenantId)
    {
        SqliteConnection.ClearAllPools();
        var sb = new StringBuilder();
        var summary = new List<string>();
        sb.AppendLine("-- Vighnesh Payroll : data exported from the phone app");
        sb.AppendLine($"-- Created {DateTime.Now:yyyy-MM-dd HH:mm}. Run in SSMS on the SAME database the data originally came from.");
        sb.AppendLine("-- Existing rows are updated, missing rows are inserted. Nothing is deleted. Take a backup first.");
        sb.AppendLine("SET NOCOUNT ON; SET XACT_ABORT ON;");
        sb.AppendLine($"DECLARE @T int = {tenantId};");
        sb.AppendLine("BEGIN TRAN;");

        using var con = new SqliteConnection($"Data Source={db3Path};Mode=ReadOnly");
        con.Open();
        foreach (var sp in Specs)
        {
            using var cmd = con.CreateCommand();
            cmd.CommandText = $"SELECT {string.Join(",", sp.Cols)} FROM {sp.Table}";
            using var rd = cmd.ExecuteReader();
            int n = 0;
            sb.AppendLine();
            sb.AppendLine($"-- {sp.Table}");
            if (sp.IdentityInsert) sb.AppendLine($"IF OBJECTPROPERTY(OBJECT_ID(N'{sp.Table}'),'TableHasIdentity')=1 SET IDENTITY_INSERT {sp.Table} ON;");
            while (rd.Read())
            {
                var vals = new Dictionary<string, string>();
                for (int i = 0; i < sp.Cols.Length; i++) vals[sp.Cols[i]] = Lit(rd.IsDBNull(i) ? null : rd.GetValue(i), sp.Cols[i]);
                var where = string.Join(" AND ", sp.Keys.Select(k => $"{k}={vals[k]}")) + " AND TenantID=@T";
                var sets = sp.Cols.Where(c => !sp.Keys.Contains(c)).Select(c => $"{c}={vals[c]}").ToList();
                var insCols = sp.Cols.ToList(); var insVals = sp.Cols.Select(c => vals[c]).ToList();
                insCols.Add("TenantID"); insVals.Add("@T");
                if (sp.ExtraCol != null) { insCols.Add(sp.ExtraCol); insVals.Add(sp.ExtraVal!); }
                if (sets.Count > 0) sb.AppendLine($"UPDATE {sp.Table} SET {string.Join(", ", sets)} WHERE {where};");
                if (sets.Count > 0) sb.AppendLine($"IF @@ROWCOUNT=0 INSERT INTO {sp.Table} ({string.Join(",", insCols)}) VALUES ({string.Join(",", insVals)});");
                else sb.AppendLine($"IF NOT EXISTS (SELECT 1 FROM {sp.Table} WHERE {where}) INSERT INTO {sp.Table} ({string.Join(",", insCols)}) VALUES ({string.Join(",", insVals)});");
                n++;
            }
            if (sp.IdentityInsert) sb.AppendLine($"IF OBJECTPROPERTY(OBJECT_ID(N'{sp.Table}'),'TableHasIdentity')=1 SET IDENTITY_INSERT {sp.Table} OFF;");
            summary.Add($"{sp.Table}: {n}");
        }
        sb.AppendLine();
        sb.AppendLine("COMMIT TRAN;");
        sb.AppendLine("PRINT 'Import finished.';");
        return (sb.ToString(), string.Join(", ", summary));
    }
}
