using System.Globalization;
using System.Text.RegularExpressions;
using Microsoft.Data.Sqlite;

namespace VighneshConverter.Services;

/// <summary>Writes the Vighnesh Payroll phone-app database (.db3) from a parsed SQL Server backup.</summary>
public static class Db3Writer
{
    static readonly string[] Ddl =
    {
        "CREATE TABLE IF NOT EXISTS Settings (Key TEXT PRIMARY KEY, Value TEXT)",
        "CREATE TABLE IF NOT EXISTS Users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL UNIQUE COLLATE NOCASE, password_hash TEXT NOT NULL, IsAdmin INTEGER NOT NULL DEFAULT 0, IsActive INTEGER NOT NULL DEFAULT 1)",
        "CREATE TABLE IF NOT EXISTS Branches (BranchCode TEXT PRIMARY KEY, IsActive INTEGER NOT NULL DEFAULT 1)",
        "CREATE TABLE IF NOT EXISTS Employees (EmployeeID INTEGER PRIMARY KEY AUTOINCREMENT, EmployeeCode TEXT NULL, EmployeeName TEXT NOT NULL, Designation TEXT NULL, BranchCode TEXT NOT NULL, DateOfJoining TEXT NULL, PFMember INTEGER NOT NULL DEFAULT 0, ESIMember INTEGER NOT NULL DEFAULT 0, UANNo TEXT NULL, ESINo TEXT NULL, BankAccount TEXT NULL, BankName TEXT NULL, IFSCCode TEXT NULL, StandardSalaryPrev REAL NOT NULL DEFAULT 0, IncrementAmount REAL NOT NULL DEFAULT 0, SalaryAdjustment REAL NOT NULL DEFAULT 0, IsActive INTEGER NOT NULL DEFAULT 1)",
        "CREATE TABLE IF NOT EXISTS MonthlyAttendance (EmployeeID INTEGER NOT NULL, AttendanceMonth TEXT NOT NULL, Lates INTEGER NOT NULL DEFAULT 0, Permissions INTEGER NOT NULL DEFAULT 0, DeductionDays REAL NOT NULL DEFAULT 0, Remarks TEXT NULL, PRIMARY KEY (EmployeeID, AttendanceMonth))",
        "CREATE TABLE IF NOT EXISTS Payroll (PayrollID INTEGER PRIMARY KEY AUTOINCREMENT, EmployeeID INTEGER NOT NULL, SalaryMonth TEXT NOT NULL, DaysInMonth INTEGER NOT NULL DEFAULT 30, Leaves REAL NOT NULL DEFAULT 0, StandardSalary REAL NOT NULL DEFAULT 0, LOP REAL NOT NULL DEFAULT 0, GrossSalary REAL NOT NULL DEFAULT 0, Basic REAL NOT NULL DEFAULT 0, DA REAL NOT NULL DEFAULT 0, PF REAL NOT NULL DEFAULT 0, ESI REAL NOT NULL DEFAULT 0, PT REAL NOT NULL DEFAULT 0, SalaryAdvance REAL NOT NULL DEFAULT 0, OtherDeductions REAL NOT NULL DEFAULT 0, TotalDeductions REAL NOT NULL DEFAULT 0, NetPay REAL NOT NULL DEFAULT 0, CreatedOn TEXT NOT NULL DEFAULT (datetime('now')), UNIQUE (EmployeeID, SalaryMonth))",
        "CREATE TABLE IF NOT EXISTS Loans (LoanID INTEGER PRIMARY KEY AUTOINCREMENT, EmployeeID INTEGER NOT NULL, TxnDate TEXT NOT NULL, OpeningBalance REAL NOT NULL DEFAULT 0, LoanAvailed REAL NOT NULL DEFAULT 0, Deduction REAL NOT NULL DEFAULT 0, NetBalance REAL NOT NULL DEFAULT 0, Remarks TEXT NULL)",
        "CREATE TABLE IF NOT EXISTS StatutoryRules (Id INTEGER PRIMARY KEY AUTOINCREMENT, RuleKey TEXT NOT NULL, RuleValue REAL NOT NULL, EffectiveFrom TEXT NOT NULL, Notes TEXT NULL, CreatedOn TEXT NOT NULL DEFAULT (datetime('now')))",
        "CREATE TABLE IF NOT EXISTS SystemAudit (AuditID INTEGER PRIMARY KEY AUTOINCREMENT, UserName TEXT NULL, ActionName TEXT NOT NULL, Details TEXT NULL, CreatedOn TEXT NOT NULL DEFAULT (datetime('now')))",
        "CREATE INDEX IF NOT EXISTS IX_Loans_Emp ON Loans(EmployeeID, TxnDate)",
        "CREATE INDEX IF NOT EXISTS IX_Payroll_Month ON Payroll(SalaryMonth)"
    };

    public static List<(int id, string name)> Tenants(BakReader b) =>
        b.Table("Tenants").Where(t => t.GetValueOrDefault("TenantID") != null)
         .Select(t => (Convert.ToInt32(t["TenantID"]), Str(t.GetValueOrDefault("OrganizationName")) ?? "")).ToList();

    static object? G(Dictionary<string, object?> r, string k) => r.TryGetValue(k, out var v) ? v : null;
    static string? Str(object? v) => v == null ? null : Convert.ToString(v, CultureInfo.InvariantCulture);
    static double Dbl(object? v) => v == null ? 0 : Convert.ToDouble(v, CultureInfo.InvariantCulture);
    static long Lng(object? v) => v == null ? 0 : Convert.ToInt64(v, CultureInfo.InvariantCulture);

    static void Exec(SqliteConnection c, SqliteTransaction tx, string sql, params object?[] args)
    {
        int i = 0;
        sql = Regex.Replace(sql, @"\?", _ => "@p" + (i++));
        using var cmd = c.CreateCommand();
        cmd.Transaction = tx;
        cmd.CommandText = sql;
        for (int k = 0; k < args.Length; k++) cmd.Parameters.AddWithValue("@p" + k, args[k] ?? DBNull.Value);
        cmd.ExecuteNonQuery();
    }

    public static string Write(BakReader b, string outPath, int? tenant, Action<string> log)
    {
        SqliteConnection.ClearAllPools();
        if (File.Exists(outPath)) File.Delete(outPath);
        var tenants = Tenants(b);
        if (tenant == null && tenants.Count > 0) tenant = tenants[0].id;
        bool Mine(Dictionary<string, object?> r) { var t = G(r, "TenantID"); return tenant == null || t == null || Lng(t) == tenant; }

        var counts = new List<string>();
        using (var con = new SqliteConnection($"Data Source={outPath}"))
        {
            con.Open();
            using var tx = con.BeginTransaction();
            foreach (var q in Ddl) Exec(con, tx, q);
            var org = tenants.FirstOrDefault(t => t.id == tenant).name;
            if (!string.IsNullOrEmpty(org)) Exec(con, tx, "INSERT INTO Settings VALUES('OrgName',?)", org);

            int n = 0;
            foreach (var u in b.Table("Users"))
            {
                if (!Mine(u) || Str(G(u, "username")) == null || Str(G(u, "password_hash")) == null) continue;
                bool admin = Lng(G(u, "IsAdmin")) != 0 || Lng(G(u, "IsOrgAdmin")) != 0;
                Exec(con, tx, "INSERT OR IGNORE INTO Users(id,username,password_hash,IsAdmin,IsActive) VALUES(?,?,?,?,?)",
                    Lng(G(u, "id")), Str(G(u, "username")), Str(G(u, "password_hash")), admin ? 1 : 0, G(u, "IsActive") == null ? 1 : Lng(G(u, "IsActive")));
                n++;
            }
            counts.Add($"Users: {n}");

            n = 0;
            foreach (var r in b.Table("Branches"))
                if (Mine(r) && Str(G(r, "BranchCode")) != null)
                { Exec(con, tx, "INSERT OR IGNORE INTO Branches VALUES(?,?)", Str(G(r, "BranchCode")), G(r, "IsActive") == null ? 1 : Lng(G(r, "IsActive"))); n++; }
            counts.Add($"Branches: {n}");

            var empIds = new HashSet<long>(); n = 0;
            foreach (var e in b.Table("Employees"))
            {
                if (!Mine(e) || Str(G(e, "EmployeeName")) == null) continue;
                Exec(con, tx, @"INSERT OR REPLACE INTO Employees(EmployeeID,EmployeeCode,EmployeeName,Designation,BranchCode,DateOfJoining,PFMember,ESIMember,UANNo,ESINo,BankAccount,BankName,IFSCCode,StandardSalaryPrev,IncrementAmount,SalaryAdjustment,IsActive)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    Lng(G(e, "EmployeeID")), Str(G(e, "EmployeeCode")), Str(G(e, "EmployeeName")), Str(G(e, "Designation")),
                    Str(G(e, "BranchCode")) ?? "MAIN", Str(G(e, "DateOfJoining")), Lng(G(e, "PFMember")), Lng(G(e, "ESIMember")),
                    Str(G(e, "UANNo")), Str(G(e, "ESINo")), Str(G(e, "BankAccount")), Str(G(e, "BankName")), Str(G(e, "IFSCCode")),
                    Dbl(G(e, "StandardSalaryPrev")), Dbl(G(e, "IncrementAmount")), Dbl(G(e, "SalaryAdjustment")), G(e, "IsActive") == null ? 1 : Lng(G(e, "IsActive")));
                empIds.Add(Lng(G(e, "EmployeeID"))); n++;
            }
            counts.Add($"Employees: {n}");

            foreach (var a in b.Table("AttendanceMonthlyEmployeeSummary"))
                if (empIds.Contains(Lng(G(a, "EmployeeID"))) && Str(G(a, "AttendanceMonth")) != null)
                    Exec(con, tx, "INSERT OR REPLACE INTO MonthlyAttendance VALUES(?,?,?,?,?,NULL)", Lng(G(a, "EmployeeID")), Str(G(a, "AttendanceMonth")),
                        Lng(G(a, "LateCount")), Lng(G(a, "PermissionCount")), Dbl(G(a, "DeductionDays")));
            foreach (var a in b.Table("PayrollStatementDeductions"))
                if (empIds.Contains(Lng(G(a, "EmployeeID"))) && Str(G(a, "AttendanceMonth")) != null)
                    Exec(con, tx, "INSERT OR IGNORE INTO MonthlyAttendance VALUES(?,?,?,?,?,NULL)", Lng(G(a, "EmployeeID")), Str(G(a, "AttendanceMonth")),
                        (long)Dbl(G(a, "Lates")), (long)Dbl(G(a, "Permissions")), Dbl(G(a, "DeductionDays")));

            n = 0;
            foreach (var p in b.Table("Payroll"))
            {
                if (!empIds.Contains(Lng(G(p, "EmployeeID"))) || Str(G(p, "SalaryMonth")) == null) continue;
                Exec(con, tx, @"INSERT OR REPLACE INTO Payroll(PayrollID,EmployeeID,SalaryMonth,DaysInMonth,Leaves,StandardSalary,LOP,GrossSalary,Basic,DA,PF,ESI,PT,SalaryAdvance,OtherDeductions,TotalDeductions,NetPay,CreatedOn)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    Lng(G(p, "PayrollID")), Lng(G(p, "EmployeeID")), Str(G(p, "SalaryMonth")), G(p, "DaysInMonth") == null ? 30 : Lng(G(p, "DaysInMonth")),
                    Dbl(G(p, "Leaves")), Dbl(G(p, "StandardSalary")), Dbl(G(p, "LOP")), Dbl(G(p, "GrossSalary")), Dbl(G(p, "Basic")), Dbl(G(p, "DA")),
                    Dbl(G(p, "PF")), Dbl(G(p, "ESI")), Dbl(G(p, "PT")), Dbl(G(p, "SalaryAdvance")), Dbl(G(p, "OtherDeductions")), Dbl(G(p, "TotalDeductions")),
                    Dbl(G(p, "NetPay")), Str(G(p, "CreatedOn")) ?? DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                n++;
            }
            counts.Add($"Payroll: {n}");

            n = 0;
            foreach (var l in b.Table("Loans"))
            {
                if (!empIds.Contains(Lng(G(l, "EmployeeID"))) || Str(G(l, "TxnDate")) == null) continue;
                Exec(con, tx, "INSERT OR REPLACE INTO Loans(LoanID,EmployeeID,TxnDate,OpeningBalance,LoanAvailed,Deduction,NetBalance,Remarks) VALUES(?,?,?,?,?,?,?,?)",
                    Lng(G(l, "LoanID")), Lng(G(l, "EmployeeID")), Str(G(l, "TxnDate")), Dbl(G(l, "OpeningBalance")), Dbl(G(l, "LoanAvailed")),
                    Dbl(G(l, "Deduction")), Dbl(G(l, "NetBalance")), Str(G(l, "Remarks")));
                n++;
            }
            counts.Add($"Loans: {n}");

            n = 0;
            foreach (var r in b.Table("StatutoryRules"))
            {
                if (!Mine(r) || Str(G(r, "RuleKey")) == null || Str(G(r, "EffectiveFrom")) == null) continue;
                Exec(con, tx, "INSERT INTO StatutoryRules(RuleKey,RuleValue,EffectiveFrom,Notes,CreatedOn) VALUES(?,?,?,?,?)",
                    Str(G(r, "RuleKey")), Dbl(G(r, "RuleValue")), Str(G(r, "EffectiveFrom")), Str(G(r, "Notes")),
                    Str(G(r, "CreatedOn")) ?? DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                n++;
            }
            counts.Add($"Statutory rules: {n}");
            tx.Commit();
        }
        SqliteConnection.ClearAllPools();
        foreach (var c in counts) log("  " + c);
        return string.Join(", ", counts);
    }
}
