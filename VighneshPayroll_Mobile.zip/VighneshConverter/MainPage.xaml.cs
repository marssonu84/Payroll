namespace VighneshConverter;

public partial class MainPage : ContentPage
{
    public MainPage() { InitializeComponent(); }
}
