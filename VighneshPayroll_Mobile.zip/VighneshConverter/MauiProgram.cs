namespace VighneshConverter;

public static class MauiProgram
{
    public static MauiApp CreateMauiApp()
    {
        var builder = MauiApp.CreateBuilder();
        builder.UseMauiApp<App>();
        builder.Services.AddMauiBlazorWebView();
        SQLitePCL.Batteries_V2.Init();
        return builder.Build();
    }
}
