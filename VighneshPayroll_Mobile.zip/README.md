# Vighnesh Payroll – Mobile (v14.7 port)

Android app (.NET 8 MAUI Blazor Hybrid). The database is a SQLite file in the app's private
storage on the phone: `empsalary.db3`. No server, no internet permission.

## Build (on a Windows/macOS PC with Visual Studio 2022 17.8+ or `dotnet` CLI)
1. `dotnet workload install maui-android`
2. `cd VighneshPayroll.Mobile`
3. Debug on a connected phone / emulator: `dotnet build -t:Run -f net10.0-android`
4. Release APK: `dotnet publish -f net10.0-android -c Release -p:AndroidPackageFormat=apk`
   (sign it with your own keystore before distributing)
5. Payroll maths regression test: `cd VighneshPayroll.Tests && dotnet run` (exit code 0 = pass)

## What was ported
| Web app | Phone app |
|---|---|
| PayrollCalculator / StatutoryRules (unchanged logic) | `Core/` |
| SQL Server + DPAPI Database.config + HybridSetup | SQLite file, no setup screen (`Data/`) |
| Setup.aspx, Login, PBKDF2 hashes (same format) | Setup / Login / Users / Change password |
| Employees (+ Excel upload) | Staff (+ CSV import, same column headings) |
| Attendance import & finalisation | Monthly attendance entry (deduction days) |
| Payroll, statutory rules effective dating | Payroll, Rules |
| Loans with running balances | Loans |
| Reports / statements | Payroll register + bank transfer CSV, payslip share |
| BackupRestore | Backup (share .db3) / Restore |

## Not ported yet
Multi-organisation/branch approval, two-step (TOTP) sign-in, licence admin, SuperAdmin recovery key,
daily-punch attendance import, Excel statements, statutory returns, in-app SQL console, website pages.

## Moving existing data from SQL Server
There is no direct file migration. Export employees to the template, Save As CSV, then Staff → Import CSV.
Payroll history and loans must be re-entered or imported by a small one-off script (ask for it if needed).
