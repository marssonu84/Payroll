namespace VighneshPayroll.Services;

public sealed class AppState
{
    public string? UserName { get; private set; }
    public bool IsAdmin { get; private set; }
    public bool IsSignedIn => UserName != null;
    public string OrgName => Settings.Get("OrgName") ?? "Vighnesh Payroll";
    public event Action? Changed;

    public void SignIn(string user, bool admin) { UserName = user; IsAdmin = admin; Changed?.Invoke(); }
    public void SignOut() { UserName = null; IsAdmin = false; Changed?.Invoke(); }
    public void Notify() => Changed?.Invoke();
}

public static class Settings
{
    public static string? Get(string key) => Data.Db.Scalar("SELECT Value FROM Settings WHERE Key=?", key) as string;
    public static void Set(string key, string value) =>
        Data.Db.Execute("INSERT INTO Settings(Key,Value) VALUES(?,?) ON CONFLICT(Key) DO UPDATE SET Value=excluded.Value", key, value);
}

public static class Audit
{
    public static void Log(string? user, string action, string? details = null) =>
        Data.Db.Execute("INSERT INTO SystemAudit(UserName,ActionName,Details) VALUES(?,?,?)", user, action, details);
}
